function editar_perfil(){

    let nome = $("#nome").val();
    let email = $("#email").val();
    let senha_velha = $("#senha-antiga").val();
    let senha = $("#senha-nova").val();

    var n = sessionStorage.getItem("user_id")
    var objeto = lista_usuarios[n];

    if (senha_velha == objeto.senha){
        alert(lista_usuarios[n].nome);
        objeto.senha = senha;
        objeto.nome = nome;
        objeto.email = email;
        
        alert(lista_usuarios[n].nome);
               
        alert("Mudança quase feita pq ainda não tem um back");
                
        window.location.href = "perfil.html";


    }
    else{
        alert("A senha antiga deve ser a senha que está usando atualmente")
    };



}